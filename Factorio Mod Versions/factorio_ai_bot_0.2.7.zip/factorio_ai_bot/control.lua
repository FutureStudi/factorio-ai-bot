-- Factorio AI Bot: Fixing Logging Issues

local function scan_game_state()
    game.print("[DEBUG]: Scanning game state...")

    local game_state = {
        resources = {},
        factories = {},
        enemies = {}
    }

    -- Scan nearby resources
    for _, entity in pairs(game.surfaces[1].find_entities_filtered({type="resource"})) do
        table.insert(game_state.resources, {name = entity.name, amount = entity.amount, position = entity.position})
    end

    -- Scan active factories
    for _, entity in pairs(game.surfaces[1].find_entities_filtered({type="assembling-machine"})) do
        table.insert(game_state.factories, {name = entity.name, status = entity.status, position = entity.position})
    end

    -- Scan enemy presence
    for _, entity in pairs(game.surfaces[1].find_entities_filtered({force="enemy"})) do
        table.insert(game_state.enemies, {name = entity.name, position = entity.position})
    end

    game.print("[DEBUG]: Finished scanning game state.")

    return game_state
end

local function ai_decision_logic()
    game.print("[DEBUG]: Running AI decision logic...")

    local state = scan_game_state()

    -- Convert game state to a string using serpent (safe serialization)
    local ai_data_string = serpent.dump(state)

    -- Fix: Log AI Data in Chunks to Avoid Truncation
    if #ai_data_string > 500 then
        local chunk_size = 500
        for i = 1, #ai_data_string, chunk_size do
            local chunk = ai_data_string:sub(i, i + chunk_size - 1)
            log("[AI Data Chunk]: " .. chunk)
        end
    else
        log("[AI Data]: " .. ai_data_string)
    end

    game.print("[DEBUG]: AI decision process completed.")
end

-- AI Loop: Runs every 300 ticks (5 seconds)
script.on_event(defines.events.on_tick, function(event)
    game.print("[DEBUG]: on_tick event triggered.")

    if event.tick % 300 == 0 then
        ai_decision_logic()
    end
end)

-- Console Command to Manually Trigger AI
commands.add_command("ai_run", "Manually triggers the AI decision logic.", function(command)
    game.print("[DEBUG]: Manual AI run command received.")
    ai_decision_logic()
end)
