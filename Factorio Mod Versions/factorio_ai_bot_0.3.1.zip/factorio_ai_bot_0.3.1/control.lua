script.on_event(defines.events.on_tick, function(event)
    if event.tick % 120 == 0 then  -- Log every 2 seconds
        local player = game.players[1]  -- Assume single player mode
        if player and player.valid then
            local pos = player.position
            local data = "[AI Player Position]: x=" .. pos.x .. ", y=" .. pos.y .. "\n"

            -- Write player position
            helpers.write_file("factorio_ai_data.txt", data, true)  

            -- Find nearby resources
            local surface = player.surface
            local resource_entities = surface.find_entities_filtered{type="resource"}

            -- If no resources are found, print debug message
            if #resource_entities == 0 then
                game.print("[DEBUG] No resources found near the player!")
            else
                game.print("[DEBUG] Logging nearby resources...")
            end

            -- Write resources to log
            for _, entity in pairs(resource_entities) do
                local resource_data = "[AI Data Chunk]: name="" .. entity.name .. "", position={x=" .. entity.position.x .. ", y=" .. entity.position.y .. "}\n"
                helpers.write_file("factorio_ai_data.txt", resource_data, true)
            end
        end
    end
end)
