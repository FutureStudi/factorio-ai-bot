global.ai_log = global.ai_log or {}  -- Store AI logs in memory

function trim_log(max_lines)
    while #global.ai_log > max_lines do
        table.remove(global.ai_log, 1)  -- Remove oldest entry
    end
end

script.on_event(defines.events.on_tick, function(event)
    if event.tick % 300 == 0 then  -- Log every 5 seconds
        local player = game.players[1]  
        if player and player.valid then
            local pos = player.position
            local data = string.format("[AI Player Position]: x=%.2f, y=%.2f\n", pos.x, pos.y)

            -- Store log in memory
            table.insert(global.ai_log, data)
            trim_log(500)  -- Keep only the latest 500 lines

            -- Write the trimmed log to file
            game.write_file("factorio_ai_data.txt", table.concat(global.ai_log, ""), false)

            -- Find nearby resources (limit scanning area)
            local surface = player.surface
            local resource_entities = surface.find_entities_filtered{
                type="resource",
                area={{pos.x - 50, pos.y - 50}, {pos.x + 50, pos.y + 50}}
            }

            -- Debug messages
            if #resource_entities == 0 then
                game.print("[DEBUG] No resources found near the player!")
            else
                game.print("[DEBUG] Logging nearby resources...")
            end

            -- Log nearby resources efficiently
            for _, entity in pairs(resource_entities) do
                local resource_data = string.format(
                    "[AI Data Chunk]: name=\"%s\", position={x=%.2f, y=%.2f}\n",
                    entity.name, entity.position.x, entity.position.y
                )
                table.insert(global.ai_log, resource_data)
            end
        end
    end
end)
