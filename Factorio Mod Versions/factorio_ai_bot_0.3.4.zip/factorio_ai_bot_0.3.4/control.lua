script.on_event(defines.events.on_tick, function(event)
    if event.tick % 120 == 0 then  -- Log every 2 seconds
        local player = game.players[1]  -- Assume single player mode
        if player and player.valid then
            local pos = player.position
            local data = string.format("[AI Player Position]: x=%.2f, y=%.2f\n", pos.x, pos.y)

            -- Write player position
            helpers.write_file("factorio_ai_data.txt", data, true)  

            -- Find nearby resources
            local surface = player.surface
            local resource_entities = surface.find_entities_filtered{type="resource"}

            -- Debug messages for resource detection
            if #resource_entities == 0 then
                game.print("[DEBUG] No resources found near the player!")
            else
                game.print("[DEBUG] Logging nearby resources...")
            end

            -- Corrected resource data logging
            for _, entity in pairs(resource_entities) do
                local resource_data = string.format(
                    "[AI Data Chunk]: name=\"%s\", position={x=%.2f, y=%.2f}\n",
                    entity.name, entity.position.x, entity.position.y
                )
                helpers.write_file("factorio_ai_data.txt", resource_data, true)
            end
        end
    end
end)
