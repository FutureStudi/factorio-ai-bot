-- Factorio AI Bot: Basic Automation Logic

local function scan_game_state()
    local game_state = {
        resources = {},
        factories = {},
        enemies = {}
    }

    -- Scan nearby resources
    for _, entity in pairs(game.surfaces[1].find_entities_filtered({type="resource"})) do
        table.insert(game_state.resources, {name = entity.name, amount = entity.amount, position = entity.position})
    end

    -- Scan active factories
    for _, entity in pairs(game.surfaces[1].find_entities_filtered({type="assembling-machine"})) do
        table.insert(game_state.factories, {name = entity.name, status = entity.status, position = entity.position})
    end

    -- Scan enemy presence
    for _, entity in pairs(game.surfaces[1].find_entities_filtered({force="enemy"})) do
        table.insert(game_state.enemies, {name = entity.name, position = entity.position})
    end

    return game_state
end

local function ai_decision_logic()
    local state = scan_game_state()

    -- Check resource levels
    local low_resources = false
    for _, res in pairs(state.resources) do
        if res.amount < 500 then
            low_resources = true
        end
    end

    -- Check enemy presence
    local under_attack = #state.enemies > 0

    -- AI Decision-making
    if under_attack then
        game.print("[AI]: Threat detected! Prioritizing defense.")
    elseif low_resources then
        game.print("[AI]: Resources running low. Expanding mining operations.")
    else
        game.print("[AI]: All systems normal. Maintaining efficiency.")
    end

    -- Log AI state to Factorio console (No file writing)
    game.print("[AI Data]: " .. serpent.block(state))
end

-- AI Loop: Runs every 300 ticks (5 seconds)
script.on_event(defines.events.on_tick, function(event)
    if event.tick % 300 == 0 then
        ai_decision_logic()
    end
end)
