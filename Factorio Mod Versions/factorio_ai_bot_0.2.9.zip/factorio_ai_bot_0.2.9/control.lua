script.on_event(defines.events.on_tick, function(event)
    if event.tick % 60 == 0 then  -- Log every second
        local player = game.players[1]  -- Assume single player mode
        if player and player.valid then
            local pos = player.position
            local data = "[AI Player Position]: x=" .. pos.x .. ", y=" .. pos.y .. "\n"

            -- Use helpers.write_file instead of game.write_file (Factorio 2.0.41 API)
            helpers.write_file("factorio_ai_data.txt", data, true)  -- Append mode

            -- Print debug message to in-game console
            game.print("[DEBUG] Player Position: x=" .. pos.x .. ", y=" .. pos.y)
        end
    end
end)
