script.on_event(defines.events.on_tick, function(event)
    if event.tick % 60 == 0 then  -- Log every second
        local player = game.players[1]  -- Assume single player for now
        if player and player.valid then
            local pos = player.position
            local data = "[AI Player Position]: x=" .. pos.x .. ", y=" .. pos.y .. "\n"

            -- Ensure logging compatibility with Factorio
            game.write_file("factorio_ai_data.txt", data, false)  
            game.write_file("script-output/factorio_ai_data.txt", data, false)

            -- Print debug message to in-game console
            game.print("[DEBUG] Player Position: x=" .. pos.x .. ", y=" .. pos.y)
        end
    end
end)
