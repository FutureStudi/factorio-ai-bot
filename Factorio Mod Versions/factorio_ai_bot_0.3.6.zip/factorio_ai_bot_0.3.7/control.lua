function trim_file(file_path, max_lines)
    local file_contents = game.read_file(file_path)
    if not file_contents then return end

    local lines = {}
    for line in file_contents:gmatch("[^\r\n]+") do
        table.insert(lines, line)
    end

    if #lines > max_lines then
        local trimmed_data = table.concat(lines, "\n", #lines - max_lines + 1, #lines)
        helpers.write_file(file_path, trimmed_data, false)  -- Overwrite with trimmed content
    end
end

script.on_event(defines.events.on_tick, function(event)
    if event.tick % 300 == 0 then  -- Log every 5 seconds
        local player = game.players[1]  
        if player and player.valid then
            local pos = player.position
            local data = string.format("[AI Player Position]: x=%.2f, y=%.2f\n", pos.x, pos.y)

            -- Write position data
            helpers.write_file("factorio_ai_data.txt", data, false)  
            trim_file("factorio_ai_data.txt", 500)  -- Keep only the latest 500 lines

            -- Find nearby resources (limit scanning area)
            local surface = player.surface
            local resource_entities = surface.find_entities_filtered{
                type="resource",
                area={{pos.x - 50, pos.y - 50}, {pos.x + 50, pos.y + 50}}
            }

            -- Debug messages to track resource detection
            if #resource_entities == 0 then
                game.print("[DEBUG] No resources found near the player!")
            else
                game.print("[DEBUG] Logging nearby resources...")
            end

            -- Log nearby resources efficiently
            for _, entity in pairs(resource_entities) do
                local resource_data = string.format(
                    "[AI Data Chunk]: name=\"%s\", position={x=%.2f, y=%.2f}\n",
                    entity.name, entity.position.x, entity.position.y
                )
                helpers.write_file("factorio_ai_data.txt", resource_data, false)  
            end
        end
    end
end)
