-- Factorio AI Bot: Basic Automation Debugging

local function scan_game_state()
    game.print("[DEBUG]: Scanning game state...") -- Debug Log

    local game_state = {
        resources = {},
        factories = {},
        enemies = {}
    }

    -- Scan nearby resources
    for _, entity in pairs(game.surfaces[1].find_entities_filtered({type="resource"})) do
        table.insert(game_state.resources, {name = entity.name, amount = entity.amount, position = entity.position})
    end

    -- Scan active factories
    for _, entity in pairs(game.surfaces[1].find_entities_filtered({type="assembling-machine"})) do
        table.insert(game_state.factories, {name = entity.name, status = entity.status, position = entity.position})
    end

    -- Scan enemy presence
    for _, entity in pairs(game.surfaces[1].find_entities_filtered({force="enemy"})) do
        table.insert(game_state.enemies, {name = entity.name, position = entity.position})
    end

    game.print("[DEBUG]: Finished scanning game state.") -- Debug Log
    return game_state
end

local function ai_decision_logic()
    game.print("[DEBUG]: Running AI decision logic...") -- Debug Log

    local state = scan_game_state()

    -- Check resource levels
    local low_resources = false
    for _, res in pairs(state.resources) do
        if res.amount < 500 then
            low_resources = true
        end
    end

    -- Check enemy presence
    local under_attack = #state.enemies > 0

    -- AI Decision-making
    if under_attack then
        game.print("[AI]: Threat detected! Prioritizing defense.")
    elseif low_resources then
        game.print("[AI]: Resources running low. Expanding mining operations.")
    else
        game.print("[AI]: All systems normal. Maintaining efficiency.")
    end

    -- Log AI state
    game.print("[DEBUG]: AI decision process completed.")
end

-- AI Loop: Runs every 300 ticks (5 seconds)
script.on_event(defines.events.on_tick, function(event)
    game.print("[DEBUG]: on_tick event triggered.") -- Debug Log

    if event.tick % 300 == 0 then
        ai_decision_logic()
    end
end)

-- Register a console command to manually trigger AI
commands.add_command("ai_run", "Manually triggers the AI decision logic.", function(command)
    game.print("[DEBUG]: Manual AI run command received.") -- Debug Log
    ai_decision_logic()
end)
